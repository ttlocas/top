const API_BASE = '';
let authToken = null;
let userRole = null;
let userName = null;

// ---------- Helpers ----------
function showAlert(msg) {
  const alertBox = document.getElementById('alert');
  if (!alertBox) {
    alert(msg);
    return;
  }
  alertBox.textContent = msg;
  alertBox.classList.remove('hidden');
  setTimeout(() => alertBox.classList.add('hidden'), 4000);
}

function saveAuth(token, role, name) {
  authToken = token;
  userRole = role;
  userName = name;
  localStorage.setItem('auth', JSON.stringify({ token, role, name }));
}

function loadAuth() {
  const raw = localStorage.getItem('auth');
  if (!raw) return;
  try {
    const data = JSON.parse(raw);
    authToken = data.token;
    userRole = data.role;
    userName = data.name;
  } catch (e) {
    console.error('Erro ao ler auth do localStorage', e);
  }
}

function clearAuth() {
  authToken = null;
  userRole = null;
  userName = null;
  localStorage.removeItem('auth');
}

async function apiRequest(path, options = {}) {
  const headers = options.headers || {};
  if (authToken && !(options.body instanceof FormData)) {
    headers['Authorization'] = `Bearer ${authToken}`;
    options.headers = headers;
  } else if (authToken && options.body instanceof FormData) {
    // FormData: não definir Content-Type manualmente
    headers['Authorization'] = `Bearer ${authToken}`;
    options.headers = headers;
  }

  const res = await fetch(API_BASE + path, options);
  let data = {};
  try {
    data = await res.json();
  } catch (e) {
    console.error('Erro ao ler JSON', e);
  }

  if (!res.ok) {
    throw new Error(data.message || 'Erro na API');
  }
  return data;
}

// ---------- UI ----------
function updateUI() {
  const authSection = document.getElementById('auth-section');
  const dashboard = document.getElementById('dashboard');
  const professorPanel = document.getElementById('professor-panel');
  const alunoPanel = document.getElementById('aluno-panel');
  const topUserRole = document.getElementById('top-user-role');
  const btnLogout = document.getElementById('btn-logout');
  const userInfo = document.getElementById('user-info');

  if (!authToken) {
    authSection.classList.remove('hidden');
    dashboard.classList.add('hidden');
    professorPanel.classList.add('hidden');
    alunoPanel.classList.add('hidden');
    topUserRole.classList.add('hidden');
    btnLogout.classList.add('hidden');
    return;
  }

  authSection.classList.add('hidden');
  dashboard.classList.remove('hidden');
  btnLogout.classList.remove('hidden');

  userInfo.textContent = `Sessão iniciada como ${userName || ''} (${userRole})`;

  if (userRole === 'PROFESSOR') {
    professorPanel.classList.remove('hidden');
    alunoPanel.classList.add('hidden');
    topUserRole.textContent = 'Professor';
    topUserRole.classList.remove('hidden');
    carregarAtividadesProfessor();
  } else {
    alunoPanel.classList.remove('hidden');
    professorPanel.classList.add('hidden');
    topUserRole.textContent = 'Aluno';
    topUserRole.classList.remove('hidden');
    carregarAtividadesAluno();
    carregarMinhasEntregas();
  }
}

// ---------- Auth ----------
async function handleRegister() {
  const name = document.getElementById('register-name').value.trim();
  const email = document.getElementById('register-email').value.trim();
  const password = document.getElementById('register-password').value.trim();
  const role = document.getElementById('register-role').value;

  if (!name || !email || !password) {
    showAlert('Preenche todos os campos de registo.');
    return;
  }

  try {
    await apiRequest('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role }),
    });
    showAlert('Utilizador registado com sucesso! Agora faz login.');
  } catch (err) {
    console.error(err);
    showAlert('Erro ao registar: ' + err.message);
  }
}

async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value.trim();

  if (!email || !password) {
    showAlert('Preenche email e palavra-passe.');
    return;
  }

  try {
    const data = await apiRequest('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    saveAuth(data.token, data.role, data.name);
    showAlert('Login realizado com sucesso!');
    updateUI();
  } catch (err) {
    console.error(err);
    showAlert('Erro ao fazer login: ' + err.message);
  }
}

function handleLogout() {
  clearAuth();
  updateUI();
}

// ---------- Professor: atividades e entregas ----------
async function carregarAtividadesProfessor() {
  try {
    const list = document.getElementById('teacher-activities-list');
    const select = document.getElementById('prof-activity-select');

    list.innerHTML = '<li class="muted">A carregar...</li>';
    if (select) {
      select.innerHTML = '<option value="">(Escolhe uma atividade)</option>';
    }

    const activities = await apiRequest('/api/activities/my', { method: 'GET' });
    list.innerHTML = '';

    if (!activities.length) {
      list.innerHTML = '<li class="muted">Ainda não criaste atividades.</li>';
      return;
    }

    activities.forEach(a => {
      const li = document.createElement('li');
      li.textContent = `${a.title} (até ${a.deadline})`;
      list.appendChild(li);

      if (select) {
        const opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = a.title;
        select.appendChild(opt);
      }
    });
  } catch (err) {
    console.error(err);
    showAlert('Erro ao carregar atividades do professor.');
  }
}

async function handleCreateActivity() {
  const title = document.getElementById('activity-title').value.trim();
  const description = document.getElementById('activity-description').value.trim();
  const deadline = document.getElementById('activity-deadline').value.trim();

  if (!title || !description || !deadline) {
    showAlert('Preenche todos os campos da atividade.');
    return;
  }

  try {
    await apiRequest('/api/activities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description, deadline }),
    });
    showAlert('Atividade criada com sucesso!');
    document.getElementById('activity-title').value = '';
    document.getElementById('activity-description').value = '';
    document.getElementById('activity-deadline').value = '';
    carregarAtividadesProfessor();
  } catch (err) {
    console.error(err);
    showAlert('Erro ao criar atividade: ' + err.message);
  }
}

async function handleLoadSubmissionsProfessor() {
  const select = document.getElementById('prof-activity-select');
  const list = document.getElementById('prof-submissions-list');
  const activityId = select?.value;

  if (!activityId) {
    showAlert('Escolhe uma atividade para ver as entregas.');
    return;
  }

  try {
    list.innerHTML = '<li class="muted">A carregar...</li>';
    const subs = await apiRequest(`/api/submissions/activity/${activityId}`, { method: 'GET' });
    list.innerHTML = '';

    if (!subs.length) {
      list.innerHTML = '<li class="muted">Ainda não há entregas para esta atividade.</li>';
      return;
    }

    subs.forEach(s => {
      const li = document.createElement('li');
      li.dataset.submissionId = s.id;

      const status = s.is_late ? 'ATRASADA' : 'no prazo';
      const gradeText = s.grade != null ? `Nota atual: ${s.grade}` : 'Ainda sem nota';

      li.innerHTML = `
        <div><strong>${s.student_name || 'Aluno #' + s.student_id}</strong> · ${status}</div>
        <div class="muted" style="font-size: 12px; margin-bottom: 6px;">
          ${gradeText}
        </div>
        <div style="display: grid; grid-template-columns: 100px 1fr auto; gap: 6px; align-items: center;">
          <input type="number" min="0" max="20" step="0.5"
                 class="grade-input"
                 placeholder="Nota"
                 value="${s.grade != null ? s.grade : ''}">
          <input type="text"
                 class="feedback-input"
                 placeholder="Comentário"
                 value="${s.feedback || ''}">
          <button class="btn btn-primary btn-save-grade">Guardar</button>
        </div>
      `;

      list.appendChild(li);
    });
  } catch (err) {
    console.error(err);
    showAlert('Erro ao carregar entregas da atividade.');
  }
}

async function handleSaveGradeClick(event) {
  const btn = event.target.closest('.btn-save-grade');
  if (!btn) return;

  const li = btn.closest('li');
  if (!li) return;

  const submissionId = li.dataset.submissionId;
  const gradeInput = li.querySelector('.grade-input');
  const feedbackInput = li.querySelector('.feedback-input');

  const grade = gradeInput.value.trim();
  const feedback = feedbackInput.value.trim();

  if (!grade) {
    showAlert('Indica uma nota.');
    return;
  }

  try {
    await apiRequest(`/api/submissions/${submissionId}/grade`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ grade, feedback }),
    });

    showAlert('Entrega avaliada com sucesso!');
    // recarregar lista para atualizar "Nota atual"
    handleLoadSubmissionsProfessor();
  } catch (err) {
    console.error(err);
    showAlert('Erro ao guardar avaliação: ' + err.message);
  }
}

async function handleRemoveSubmissionClick(event) {
  const btn = event.target.closest('.btn-remove-submission');
  if (!btn) return;

  const li = btn.closest('li');
  if (!li) return;

  const submissionId = li.dataset.submissionId;

  if (!confirm('Tens a certeza que queres remover esta entrega?')) {
    return;
  }

  try {
    await apiRequest(`/api/submissions/${submissionId}`, {
      method: 'DELETE',
    });

    showAlert('Entrega removida com sucesso!');
    // Recarregar lista de entregas e atividades (para permitir novo upload)
    carregarMinhasEntregas();
  } catch (err) {
    console.error(err);
    showAlert('Erro ao remover entrega: ' + err.message);
  }
}


// ---------- Aluno: atividades, upload e entregas ----------
async function carregarAtividadesAluno() {
  try {
    const list = document.getElementById('student-activities-list');
    const select = document.getElementById('upload-activity');

    list.innerHTML = '<li class="muted">A carregar...</li>';
    if (select) {
      select.innerHTML = '<option value="">(Escolhe uma atividade)</option>';
    }

    const activities = await apiRequest('/api/activities', { method: 'GET' });
    list.innerHTML = '';

    if (!activities.length) {
      list.innerHTML = '<li class="muted">Ainda não há atividades.</li>';
      return;
    }

    activities.forEach(a => {
      const li = document.createElement('li');

      li.innerHTML = `
        <div><strong>${a.title}</strong> (prof: ${a.teacher_name || '—'})</div>
        <div class="muted" style="font-size: 13px; margin: 3px 0 4px;">
          Data limite: ${a.deadline}
        </div>
        <div style="font-size: 13px;">
          ${a.description || '<em>Sem descrição.</em>'}
        </div>
      `;

      list.appendChild(li);

      if (select) {
        const opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = a.title;
        select.appendChild(opt);
      }
    });
  } catch (err) {
    console.error(err);
    showAlert('Erro ao carregar atividades.');
  }
}


async function handleUpload() {
  const select = document.getElementById('upload-activity');
  const fileInput = document.getElementById('upload-file');

  const activityId = select?.value;
  const file = fileInput?.files[0];

  if (!activityId) {
    showAlert('Escolhe uma atividade.');
    return;
  }
  if (!file) {
    showAlert('Escolhe um ficheiro para enviar.');
    return;
  }

  try {
    const formData = new FormData();
    formData.append('activityId', activityId);
    formData.append('file', file);

    await apiRequest('/api/submissions', {
      method: 'POST',
      body: formData,
    });

    showAlert('Trabalho enviado com sucesso!');
    fileInput.value = '';
    carregarMinhasEntregas();
  } catch (err) {
    console.error(err);
    showAlert('Erro ao enviar trabalho: ' + err.message);
  }
}

async function carregarMinhasEntregas() {
  try {
    const list = document.getElementById('student-submissions-list');
    if (!list) return;

    list.innerHTML = '<li class="muted">A carregar...</li>';

    const subs = await apiRequest('/api/submissions/my', { method: 'GET' });
    list.innerHTML = '';

    if (!subs.length) {
      list.innerHTML = '<li class="muted">Ainda não tens entregas.</li>';
      return;
    }

    subs.forEach(s => {
          const li = document.createElement('li');
    li.dataset.submissionId = s.id; // guardar o id aqui

    const status = s.is_late ? 'ATRASADA' : 'no prazo';
    const gradeText = s.grade != null ? ` · Nota: ${s.grade}` : '';
    const feedbackText = s.feedback ? `<div class="muted" style="font-size: 12px;">Comentário do professor: ${s.feedback}</div>` : '';

    // 🔽 só mostra botão remover se ainda não tiver nota
    const canRemove = (s.grade === null || s.grade === undefined);

    li.innerHTML = `
      <div><strong>${s.activity_title || 'Atividade #'+s.activity_id}</strong></div>
      <div style="font-size: 13px;">
        Estado: ${status}${gradeText}
      </div>
      ${feedbackText}
      ${
        canRemove
          ? `<div style="margin-top: 6px; text-align: right;">
               <button class="btn btn-primary btn-remove-submission" style="background:#e53935;">Remover entrega</button>
             </div>`
          : `<div class="muted" style="margin-top: 6px; font-size: 12px; text-align:right;">
               Esta entrega já foi avaliada e não pode ser removida.
             </div>`
      }
    `;
    list.appendChild(li);

      list.appendChild(li);
    });
  } catch (err) {
    console.error(err);
    showAlert('Erro ao carregar as tuas entregas.');
  }
}


// ---------- Inicialização ----------
window.addEventListener('DOMContentLoaded', () => {
  console.log('app.js carregado');
  loadAuth();
  updateUI();

  document.getElementById('btn-register')?.addEventListener('click', handleRegister);
  document.getElementById('btn-login')?.addEventListener('click', handleLogin);
  document.getElementById('btn-logout')?.addEventListener('click', handleLogout);
  document.getElementById('btn-create-activity')?.addEventListener('click', handleCreateActivity);
  document.getElementById('btn-upload')?.addEventListener('click', handleUpload);
  document.getElementById('btn-load-submissions')?.addEventListener('click', handleLoadSubmissionsProfessor);
  document.getElementById('prof-submissions-list')?.addEventListener('click', handleSaveGradeClick);
  document.getElementById('student-submissions-list')?.addEventListener('click', handleRemoveSubmissionClick);
});
