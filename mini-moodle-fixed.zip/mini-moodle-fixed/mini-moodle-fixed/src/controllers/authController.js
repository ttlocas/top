const userModel = require('../models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

async function register(req, res) {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: 'Campos obrigatórios em falta.' });
    }

    if (!['ALUNO', 'PROFESSOR'].includes(role)) {
      return res.status(400).json({ message: 'Papel inválido.' });
    }

    const id = await userModel.createUser({ name, email, password, role });
    return res.status(201).json({ message: 'Utilizador criado.', userId: id });
  } catch (err) {
    console.error('Erro no register:', err);
    if (err.message === 'Email já registado') {
      return res.status(409).json({ message: err.message });
    }
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;

    const user = await userModel.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Credenciais inválidas.' });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ message: 'Credenciais inválidas.' });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, name: user.name },
      process.env.JWT_SECRET || 'default_secret',
      { expiresIn: '8h' }
    );

    return res.json({ message: 'Login OK', token, role: user.role, name: user.name });
  } catch (err) {
    console.error('Erro no login:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

module.exports = { register, login };
