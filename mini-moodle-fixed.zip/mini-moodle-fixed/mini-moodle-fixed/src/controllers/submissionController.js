const submissionModel = require('../models/submissionModel');
const activityModel = require('../models/activityModel');
const path = require('path');

// ALUNO: criar entrega
async function createSubmission(req, res) {
  try {
    const user = req.user;
    if (!user || user.role !== 'ALUNO') {
      return res.status(403).json({ message: 'Apenas alunos podem submeter trabalhos.' });
    }

    const { activityId } = req.body;
    if (!activityId) {
      return res.status(400).json({ message: 'Atividade é obrigatória.' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'Ficheiro é obrigatório.' });
    }

    const activity = await activityModel.getActivityById(activityId);
    if (!activity) {
      return res.status(404).json({ message: 'Atividade não encontrada.' });
    }

    // ⚠️ NOVO: não deixar enviar 2x para a mesma atividade
    const existing = await submissionModel.getSubmissionForStudentAndActivity(activityId, user.id);
    if (existing) {
      return res.status(400).json({
        message: 'Já tens uma entrega para esta atividade. Remove a entrega anterior antes de enviar outra.',
      });
    }

    const submittedAt = new Date();
    const deadline = new Date(activity.deadline);
    const isLate = submittedAt > deadline;

    const filePath = path.join('uploads', req.file.filename);

    const id = await submissionModel.createSubmission({
      activityId,
      studentId: user.id,
      filePath,
      submittedAt: submittedAt.toISOString(),
      isLate,
    });

    return res.status(201).json({ message: 'Entrega registada.', submissionId: id });
  } catch (err) {
    console.error('Erro ao criar entrega:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

// PROFESSOR: ver entregas de uma atividade
async function listSubmissionsByActivity(req, res) {
  try {
    const user = req.user;
    if (!user || user.role !== 'PROFESSOR') {
      return res.status(403).json({ message: 'Apenas professores.' });
    }

    const { activityId } = req.params;
    const subs = await submissionModel.getSubmissionsByActivity(activityId);
    return res.json(subs);
  } catch (err) {
    console.error('Erro a listar entregas:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

// ALUNO: ver as próprias entregas
async function listSubmissionsByStudent(req, res) {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ message: 'Não autenticado.' });
    }

    const subs = await submissionModel.getSubmissionsByStudent(user.id);
    return res.json(subs);
  } catch (err) {
    console.error('Erro a listar entregas do aluno:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

// PROFESSOR: atribuir nota e feedback
async function gradeSubmission(req, res) {
  try {
    const user = req.user;
    if (!user || user.role !== 'PROFESSOR') {
      return res.status(403).json({ message: 'Apenas professores podem avaliar entregas.' });
    }

    const { submissionId } = req.params;
    const { grade, feedback } = req.body;

    if (grade === undefined || grade === null || grade === '') {
      return res.status(400).json({ message: 'Nota é obrigatória.' });
    }

    const numericGrade = Number(grade);
    if (Number.isNaN(numericGrade) || numericGrade < 0 || numericGrade > 20) {
      return res.status(400).json({ message: 'Nota deve ser um número entre 0 e 20.' });
    }

    const submission = await submissionModel.getSubmissionById(submissionId);
    if (!submission) {
      return res.status(404).json({ message: 'Entrega não encontrada.' });
    }

    const ok = await submissionModel.updateSubmissionGrade(submissionId, numericGrade, feedback || null);
    if (!ok) {
      return res.status(500).json({ message: 'Não foi possível atualizar a entrega.' });
    }

    return res.json({ message: 'Entrega avaliada com sucesso.', grade: numericGrade, feedback: feedback || null });
  } catch (err) {
    console.error('Erro ao avaliar entrega:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

// ⚠️ NOVO: ALUNO remove a própria entrega
// ⚠️ ALUNO remove a própria entrega
async function deleteSubmission(req, res) {
  try {
    const user = req.user;
    if (!user || user.role !== 'ALUNO') {
      return res.status(403).json({ message: 'Apenas alunos podem remover as suas entregas.' });
    }

    const { submissionId } = req.params;

    const sub = await submissionModel.getSubmissionById(submissionId);
    if (!sub) {
      return res.status(404).json({ message: 'Entrega não encontrada.' });
    }

    if (sub.student_id !== user.id) {
      return res.status(403).json({ message: 'Não podes remover entregas de outros alunos.' });
    }

    // 🚫 NOVO: não deixar remover se já tiver nota
    if (sub.grade !== null && sub.grade !== undefined) {
      return res.status(400).json({ message: 'Não podes remover uma entrega que já foi avaliada.' });
    }

    const ok = await submissionModel.deleteSubmission(submissionId, user.id);
    if (!ok) {
      return res.status(500).json({ message: 'Não foi possível remover a entrega.' });
    }

    return res.json({ message: 'Entrega removida com sucesso.' });
  } catch (err) {
    console.error('Erro ao remover entrega:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}


module.exports = {
  createSubmission,
  listSubmissionsByActivity,
  listSubmissionsByStudent,
  gradeSubmission,
  deleteSubmission,
};
