// src/models/submissionModel.js
const db = require('../database/db');

async function createSubmission({ activityId, studentId, filePath, submittedAt, isLate }) {
  const stmt = db.prepare(`
    INSERT INTO submissions (activity_id, student_id, file_path, submitted_at, is_late)
    VALUES (?, ?, ?, ?, ?)
  `);

  const info = stmt.run(activityId, studentId, filePath, submittedAt, isLate ? 1 : 0);
  return info.lastInsertRowid;
}

// Entregas de uma atividade (professor vê)
async function getSubmissionsByActivity(activityId) {
  const stmt = db.prepare(`
    SELECT s.*, u.name AS student_name, u.email AS student_email
    FROM submissions s
    JOIN users u ON u.id = s.student_id
    WHERE s.activity_id = ?
    ORDER BY s.submitted_at ASC
  `);
  return stmt.all(activityId);
}

// Entregas de um aluno (aluno vê)
async function getSubmissionsByStudent(studentId) {
  const stmt = db.prepare(`
    SELECT s.*, a.title AS activity_title
    FROM submissions s
    JOIN activities a ON a.id = s.activity_id
    WHERE s.student_id = ?
    ORDER BY s.submitted_at ASC
  `);
  return stmt.all(studentId);
}

async function getSubmissionById(id) {
  const stmt = db.prepare(`SELECT * FROM submissions WHERE id = ?`);
  const sub = stmt.get(id);
  return sub || null;
}

async function updateSubmissionGrade(submissionId, grade, feedback) {
  const stmt = db.prepare(`
    UPDATE submissions
    SET grade = ?, feedback = ?
    WHERE id = ?
  `);
  const info = stmt.run(grade, feedback, submissionId);
  return info.changes > 0;
}

// ⚠️ NOVO: obter entrega de um aluno para uma atividade específica
async function getSubmissionForStudentAndActivity(activityId, studentId) {
  const stmt = db.prepare(`
    SELECT *
    FROM submissions
    WHERE activity_id = ? AND student_id = ?
    LIMIT 1
  `);
  const sub = stmt.get(activityId, studentId);
  return sub || null;
}

// ⚠️ NOVO: apagar entrega (garantindo que é mesmo do aluno)
async function deleteSubmission(id, studentId) {
  const stmt = db.prepare(`
    DELETE FROM submissions
    WHERE id = ? AND student_id = ?
  `);
  const info = stmt.run(id, studentId);
  return info.changes > 0;
}

module.exports = {
  createSubmission,
  getSubmissionsByActivity,
  getSubmissionsByStudent,
  getSubmissionById,
  updateSubmissionGrade,
  getSubmissionForStudentAndActivity,
  deleteSubmission,
};
