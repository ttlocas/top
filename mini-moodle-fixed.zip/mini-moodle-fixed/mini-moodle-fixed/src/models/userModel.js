const db = require('../database/db');
const bcrypt = require('bcrypt');

async function createUser({ name, email, password, role }) {
  const existing = await findUserByEmail(email);
  if (existing) {
    throw new Error('Email já registado');
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const stmt = db.prepare(`
    INSERT INTO users (name, email, password_hash, role)
    VALUES (?, ?, ?, ?)
  `);

  const info = stmt.run(name, email, passwordHash, role);
  return info.lastInsertRowid;
}

async function findUserByEmail(email) {
  const stmt = db.prepare(`SELECT * FROM users WHERE email = ?`);
  const user = stmt.get(email);
  return user || null;
}

module.exports = {
  createUser,
  findUserByEmail,
};
