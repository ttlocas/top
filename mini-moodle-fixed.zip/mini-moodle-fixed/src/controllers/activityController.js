const activityModel = require('../models/activityModel');

async function createActivity(req, res) {
  try {
    const { title, description, deadline } = req.body;
    const user = req.user;

    if (!user || user.role !== 'PROFESSOR') {
      return res.status(403).json({ message: 'Apenas professores podem criar atividades.' });
    }

    if (!title || !description || !deadline) {
      return res.status(400).json({ message: 'Campos obrigatórios em falta.' });
    }

    const id = await activityModel.createActivity({
      teacherId: user.id,
      title,
      description,
      deadline,
    });

    return res.status(201).json({ message: 'Atividade criada.', activityId: id });
  } catch (err) {
    console.error('Erro ao criar atividade:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

async function listActivitiesForTeacher(req, res) {
  try {
    const user = req.user;
    if (!user || user.role !== 'PROFESSOR') {
      return res.status(403).json({ message: 'Apenas professores.' });
    }

    const activities = await activityModel.getActivitiesByTeacher(user.id);
    return res.json(activities);
  } catch (err) {
    console.error('Erro a listar atividades do professor:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

async function listAllActivities(req, res) {
  try {
    const activities = await activityModel.getAllActivities();
    return res.json(activities);
  } catch (err) {
    console.error('Erro a listar atividades:', err);
    return res.status(500).json({ message: 'Erro no servidor.' });
  }
}

module.exports = {
  createActivity,
  listActivitiesForTeacher,
  listAllActivities,
};
