const db = require('../database/db');

async function createActivity({ teacherId, title, description, deadline }) {
  const createdAt = new Date().toISOString();

  const stmt = db.prepare(`
    INSERT INTO activities (teacher_id, title, description, created_at, deadline)
    VALUES (?, ?, ?, ?, ?)
  `);

  const info = stmt.run(teacherId, title, description, createdAt, deadline);
  return info.lastInsertRowid;
}

async function getActivitiesByTeacher(teacherId) {
  const stmt = db.prepare(`
    SELECT * FROM activities
    WHERE teacher_id = ?
    ORDER BY created_at DESC
  `);
  return stmt.all(teacherId);
}

async function getAllActivities() {
  const stmt = db.prepare(`
    SELECT a.*, u.name AS teacher_name
    FROM activities a
    JOIN users u ON u.id = a.teacher_id
    ORDER BY a.created_at DESC
  `);
  return stmt.all();
}

async function getActivityById(id) {
  const stmt = db.prepare(`
    SELECT a.*, u.name AS teacher_name
    FROM activities a
    JOIN users u ON u.id = a.teacher_id
    WHERE a.id = ?
  `);
  const activity = stmt.get(id);
  return activity || null;
}

module.exports = {
  createActivity,
  getActivitiesByTeacher,
  getAllActivities,
  getActivityById,
};
