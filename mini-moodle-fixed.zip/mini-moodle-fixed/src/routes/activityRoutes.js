const express = require('express');
const router = express.Router();
const activityController = require('../controllers/activityController');
const authMiddleware = require('../middleware/authMiddleware');

// criar atividade (professor)
router.post('/', authMiddleware, activityController.createActivity);

// listar atividades do professor autenticado
router.get('/my', authMiddleware, activityController.listActivitiesForTeacher);

// listar todas as atividades (alunos)
router.get('/', authMiddleware, activityController.listAllActivities);

module.exports = router;
