const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const authMiddleware = require('../middleware/authMiddleware');
const submissionController = require('../controllers/submissionController');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(process.cwd(), 'uploads'));
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, unique + ext);
  }
});
const upload = multer({ storage });

// ALUNO: faz entrega
router.post('/', authMiddleware, upload.single('file'), submissionController.createSubmission);

// PROFESSOR: vê entregas de uma atividade
router.get('/activity/:activityId', authMiddleware, submissionController.listSubmissionsByActivity);

// ALUNO: vê as suas próprias entregas
router.get('/my', authMiddleware, submissionController.listSubmissionsByStudent);

// PROFESSOR: avaliar uma entrega
router.put('/:submissionId/grade', authMiddleware, submissionController.gradeSubmission);

// ⚠️ NOVO: ALUNO remove a própria entrega
router.delete('/:submissionId', authMiddleware, submissionController.deleteSubmission);

module.exports = router;
